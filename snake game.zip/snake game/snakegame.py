from myshape import *
import pygame,random
BLACK = (0, 0, 0)
green=(0,255,0)
blue=(0,0,255)
WHITE = (255, 255, 255)

 
# Set the width and height of each snake segment
segment_width = 15
segment_height = 15
# Margin between each segment
segment_margin = 3
 
# Set initial speed
x_change = segment_width + segment_margin
y_change = 0
 
# Call this function so the Pygame library can initialize itself
pygame.init()
 
# Create an 800x600 sized screen
screen = pygame.display.set_mode([800, 600])
 
# Set the title of the window
pygame.display.set_caption('Snake Example')
 
allspriteslist = pygame.sprite.Group()
 
# Create an initial snake
snake_segments = []
for i in range(15):
    x = 250 - (segment_width + segment_margin) * i
    y = 30
    segment = SnakeShape(x, y)
    snake_segments.append(segment)
    allspriteslist.add(segment)
 
 
clock = pygame.time.Clock()
done = False
 
while not done:
 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        #Key Events for UP/DOWN/LEFT/RIGHT.
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                x_change = (segment_width + segment_margin) * -1
                y_change = 0
            if event.key == pygame.K_RIGHT:
                x_change = (segment_width + segment_margin)
                y_change = 0
            if event.key == pygame.K_UP:
                x_change = 0
                y_change = (segment_height + segment_margin) * -1
            if event.key == pygame.K_DOWN:
                x_change = 0
                y_change = (segment_height + segment_margin)
 
    # Get rid of last segment of the snake
    # .pop() command removes last item in list
    old_segment = snake_segments.pop()
    allspriteslist.remove(old_segment)
 
    # Figure out where new segment will be
    x = snake_segments[0].rect.x + x_change
    y = snake_segments[0].rect.y + y_change
    segment = SnakeShape(x, y)
    #End the game logic
    if (x>=785 or y>=585) or (x<=15 or y<=15):
        done=True
        break
    # Insert new segment into the list
    snake_segments.insert(0, segment)
    allspriteslist.add(segment)
    screen.fill(BLACK)
    allspriteslist.draw(screen)
    pygame.display.update()
    clock.tick(5)

if done is True:
    print("hello")
    #print(pygame.font.get_fonts())
    font = pygame.font.Font('freesansbold.ttf', 100)
    text = font.render('Looser', True, green, blue)
    textRect = text.get_rect()
    textRect.center=(random.randrange(50,300),random.randrange(100,150))
    screen.fill(WHITE)
    screen.blit(text,textRect)

pygame.display.update()
pygame.quit()
