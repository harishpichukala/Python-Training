import pygame
import random

WIDTH = 480
HEIGHT = 600
FPS = 60

# define colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)

# initialize pygame and create window
pygame.init()
pygame.mixer.init()
from myshape import *
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tarun Game")
clock = pygame.time.Clock()



all_sprites = pygame.sprite.Group()
mobs = pygame.sprite.Group()
#create bullet sprite
bullets = pygame.sprite.Group()
player = Player()
all_sprites.add(player)
for i in range(8):
    m = Mob()
    all_sprites.add(m)
    mobs.add(m)

def shoot():
    bullet = Bullet(player.rect.centerx, player.rect.top)
    all_sprites.add(bullet)
    bullets.add(bullet)
# Game loop
done = True
while done:
    # keep loop running at the right speed
    clock.tick(FPS)
    # Process input (events)
    for event in pygame.event.get():
        # check for closing window
        if event.type == pygame.QUIT:
            done = False
        #new logic to shoot
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                shoot()
     # update
    all_sprites.update()
    #Game End Logic

    #new logic bullet hit a mob
    hits = pygame.sprite.groupcollide(mobs, bullets, True, True)
    for hit in hits:
        m = Mob()
        all_sprites.add(m)
        mobs.add(m)
    hits=pygame.sprite.spritecollide(player,mobs,False)
    if hits:
        done = False
    # Draw / render
    screen.fill(BLACK)
    all_sprites.draw(screen)
    # *after* drawing everything, flip the display
    pygame.display.flip()

if done is False:
    font = pygame.font.Font('freesansbold.ttf', 100)
    text = font.render('Looser', True, GREEN,BLUE)
    textRect = text.get_rect()
    textRect.center=(random.randrange(50,300),random.randrange(100,150))
    screen.fill(WHITE)
    screen.blit(text,textRect)

pygame.display.update()
pygame.quit()
